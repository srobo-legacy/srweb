from controller import Controller

cont = Controller()
cont.main()
