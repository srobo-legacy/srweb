SR Control
==========

This is a graphical control program for Student Robotics kit, that will run on the Power Board.
