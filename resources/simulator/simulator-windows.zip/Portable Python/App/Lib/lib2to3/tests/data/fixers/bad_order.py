from lib2to3.fixer_base import BaseFix

class FixBadOrder(BaseFix):

    order = "crazy"
