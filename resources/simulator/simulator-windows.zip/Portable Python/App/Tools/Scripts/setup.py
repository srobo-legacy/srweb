from distutils.core import setup

if __name__ == '__main__':
    setup(
      scripts=[
        'byteyears.py',
        'checkpyc.py',
        'copytime.py',
        'crlf.py',
        'dutree.py',
        'ftpmirror.py',
        'h2py.py',
        'lfcr.py',
        '../i18n/pygettext.py',
        'logmerge.py',
        '../../Lib/tabnanny.py',
        '../../Lib/timeit.py',
        'untabify.py',
        ],
      )
